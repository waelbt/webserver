<?php
while (true) {
}
?>