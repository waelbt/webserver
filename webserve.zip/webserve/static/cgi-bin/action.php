Hi <?php
echo $_POST['name'];
?>